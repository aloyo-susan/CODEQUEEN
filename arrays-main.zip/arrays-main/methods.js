
let names = ['essy','janny','prossy','mariam'];


// console.log(names.toString());

// let joinnames = names.join(' and ');
// console.log(joinnames);

// let names2 = ['eric','bless'];
// let combinenames = names.concat(names2);
// console.log(combinenames);

// let popedname = names.pop();
// console.log(popedname);
// console.log(names)

// let pushnames = names.push('shine');
// console.log(pushnames);
// console.log(names);

// let splicednames = names.splice(1,2,'precious','adrine')
// console.log(splicednames);
// console.log(names)

let slicenames = names.slice(2,4);
console.log(slicenames);



